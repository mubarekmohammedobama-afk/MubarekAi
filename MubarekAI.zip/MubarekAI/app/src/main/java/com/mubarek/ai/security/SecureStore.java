package com.mubarek.ai.security;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import java.io.IOException;
import java.security.GeneralSecurityException;

/**
 * Stores API keys encrypted with a key held in the Android Keystore.
 * Keys are never written to logs, source code, or plain preferences.
 */
public final class SecureStore {
    private static volatile SecureStore instance;
    private final SharedPreferences prefs;

    public static SecureStore get(Context context) {
        if (instance == null) {
            synchronized (SecureStore.class) {
                if (instance == null) {
                    instance = new SecureStore(context.getApplicationContext());
                }
            }
        }
        return instance;
    }

    private SecureStore(Context context) {
        try {
            MasterKey masterKey = new MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();
            prefs = EncryptedSharedPreferences.create(
                    context,
                    "mubarek_secure",
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);
        } catch (GeneralSecurityException | IOException e) {
            throw new IllegalStateException("Secure storage is unavailable on this device", e);
        }
    }

    public String getApiKey(String providerId) {
        String v = prefs.getString("key_" + providerId, "");
        return v == null ? "" : v;
    }

    public boolean hasApiKey(String providerId) {
        return !getApiKey(providerId).isEmpty();
    }

    public void setApiKey(String providerId, String key) {
        prefs.edit().putString("key_" + providerId, key).apply();
    }

    public void deleteApiKey(String providerId) {
        prefs.edit().remove("key_" + providerId).apply();
    }
}
