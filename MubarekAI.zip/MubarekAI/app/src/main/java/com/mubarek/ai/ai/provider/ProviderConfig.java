package com.mubarek.ai.ai.provider;

public class ProviderConfig {
    public String providerId;
    public String baseUrl;
    public String apiKey;
    public String model;
    /** Negative = omit from the request. */
    public float temperature = -1f;
    public int maxTokens = 2048;
    public String systemPrompt = "";
}
