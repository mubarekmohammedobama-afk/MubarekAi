package com.mubarek.ai.ui.onboarding;

import android.content.Intent;
import android.os.Bundle;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.mubarek.ai.R;
import com.mubarek.ai.data.local.AppPrefs;
import com.mubarek.ai.ui.settings.SettingsActivity;
import com.mubarek.ai.utils.InsetsUtil;

public class OnboardingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        EdgeToEdge.enable(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding);
        InsetsUtil.apply(findViewById(R.id.root));

        final AppPrefs prefs = new AppPrefs(this);
        RadioGroup group = findViewById(R.id.themeGroup);
        int mode = prefs.getThemeMode();
        group.check(mode == AppPrefs.THEME_LIGHT ? R.id.rbLight
                : mode == AppPrefs.THEME_DARK ? R.id.rbDark : R.id.rbSystem);
        group.setOnCheckedChangeListener((g, checkedId) -> {
            int m = checkedId == R.id.rbLight ? AppPrefs.THEME_LIGHT
                    : checkedId == R.id.rbDark ? AppPrefs.THEME_DARK : AppPrefs.THEME_SYSTEM;
            if (m != prefs.getThemeMode()) {
                prefs.setThemeMode(m);
                AppPrefs.applyTheme(m);
            }
        });

        findViewById(R.id.btnSetup).setOnClickListener(v -> {
            prefs.setOnboarded(true);
            startActivity(new Intent(this, SettingsActivity.class));
            finish();
        });
        findViewById(R.id.btnLater).setOnClickListener(v -> {
            prefs.setOnboarded(true);
            finish();
        });
    }
}
