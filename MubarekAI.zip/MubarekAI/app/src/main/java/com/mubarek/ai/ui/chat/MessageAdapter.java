package com.mubarek.ai.ui.chat;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mubarek.ai.R;
import com.mubarek.ai.data.local.MessageEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import io.noties.markwon.Markwon;

public class MessageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public interface Listener {
        void onCopy(String text);
        void onRegenerate();
        void onEdit(MessageEntity message);
        void onResend();
    }

    private static final int TYPE_USER = 0;
    private static final int TYPE_AI = 1;

    private final Markwon markwon;
    private final Listener listener;
    private List<MessageEntity> items = new ArrayList<>();

    public MessageAdapter(Context context, Listener listener) {
        this.markwon = Markwon.create(context);
        this.listener = listener;
    }

    /** Efficiently handles streaming: if only the last item's text changed, rebind just that row. */
    public void setItems(List<MessageEntity> newItems) {
        List<MessageEntity> old = items;
        items = newItems;
        if (!old.isEmpty() && old.size() == newItems.size()) {
            boolean sameExceptLast = true;
            for (int i = 0; i < old.size() - 1; i++) {
                MessageEntity a = old.get(i);
                MessageEntity b = newItems.get(i);
                if (a.id != b.id || !Objects.equals(a.content, b.content)) {
                    sameExceptLast = false;
                    break;
                }
            }
            int last = old.size() - 1;
            if (sameExceptLast && old.get(last).id == newItems.get(last).id) {
                notifyItemChanged(last);
                return;
            }
        }
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() { return items.size(); }

    @Override
    public int getItemViewType(int position) {
        return "user".equals(items.get(position).role) ? TYPE_USER : TYPE_AI;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inf = LayoutInflater.from(parent.getContext());
        if (viewType == TYPE_USER) {
            return new UserHolder(inf.inflate(R.layout.item_message_user, parent, false));
        }
        return new AiHolder(inf.inflate(R.layout.item_message_ai, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        final MessageEntity m = items.get(position);
        final boolean isLast = position == items.size() - 1;
        final boolean persisted = m.id > 0;

        if (holder instanceof UserHolder) {
            UserHolder h = (UserHolder) holder;
            h.text.setText(m.content);
            h.edit.setVisibility(persisted ? View.VISIBLE : View.GONE);
            h.copy.setVisibility(persisted ? View.VISIBLE : View.GONE);
            h.resend.setVisibility(persisted && isLast ? View.VISIBLE : View.GONE);
            h.edit.setOnClickListener(v -> listener.onEdit(m));
            h.copy.setOnClickListener(v -> listener.onCopy(m.content));
            h.resend.setOnClickListener(v -> listener.onResend());
        } else {
            AiHolder h = (AiHolder) holder;
            if (m.content == null || m.content.isEmpty()) {
                h.text.setText("…");
            } else {
                markwon.setMarkdown(h.text, m.content);
            }
            h.actions.setVisibility(persisted ? View.VISIBLE : View.GONE);
            h.regenerate.setVisibility(persisted && isLast ? View.VISIBLE : View.GONE);
            h.copy.setOnClickListener(v -> listener.onCopy(m.content));
            h.regenerate.setOnClickListener(v -> listener.onRegenerate());
        }
    }

    static class UserHolder extends RecyclerView.ViewHolder {
        final TextView text;
        final ImageButton edit, copy, resend;

        UserHolder(View v) {
            super(v);
            text = v.findViewById(R.id.userText);
            edit = v.findViewById(R.id.btnEdit);
            copy = v.findViewById(R.id.btnCopy);
            resend = v.findViewById(R.id.btnResend);
        }
    }

    static class AiHolder extends RecyclerView.ViewHolder {
        final TextView text;
        final View actions;
        final ImageButton copy, regenerate;

        AiHolder(View v) {
            super(v);
            text = v.findViewById(R.id.aiText);
            actions = v.findViewById(R.id.aiActions);
            copy = v.findViewById(R.id.btnCopy);
            regenerate = v.findViewById(R.id.btnRegenerate);
        }
    }
}
