package com.mubarek.ai.data.local;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatDelegate;

import com.mubarek.ai.ai.provider.ProviderCatalog;
import com.mubarek.ai.ai.provider.ProviderConfig;

/** Non-sensitive settings. API keys live in SecureStore, never here. */
public class AppPrefs {
    public static final int THEME_SYSTEM = 0;
    public static final int THEME_LIGHT = 1;
    public static final int THEME_DARK = 2;

    public static final String DEFAULT_SYSTEM_PROMPT =
            "You are Mubarek AI, a helpful, honest and concise assistant.";

    private final SharedPreferences sp;

    public AppPrefs(Context context) {
        sp = context.getApplicationContext()
                .getSharedPreferences("mubarek_prefs", Context.MODE_PRIVATE);
    }

    public static void applyTheme(int mode) {
        switch (mode) {
            case THEME_LIGHT:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                break;
            case THEME_DARK:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                break;
            default:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
        }
    }

    public int getThemeMode() { return sp.getInt("theme", THEME_SYSTEM); }
    public void setThemeMode(int m) { sp.edit().putInt("theme", m).apply(); }

    public boolean isOnboarded() { return sp.getBoolean("onboarded", false); }
    public void setOnboarded(boolean b) { sp.edit().putBoolean("onboarded", b).apply(); }

    public String getActiveProvider() {
        return sp.getString("active_provider", ProviderCatalog.ALL.get(0).id);
    }
    public void setActiveProvider(String id) { sp.edit().putString("active_provider", id).apply(); }

    public String getBaseUrl(String id) {
        return sp.getString("base_" + id, ProviderCatalog.get(id).defaultBaseUrl);
    }
    public void setBaseUrl(String id, String v) { sp.edit().putString("base_" + id, v).apply(); }

    public String getModel(String id) {
        return sp.getString("model_" + id, ProviderCatalog.get(id).defaultModel);
    }
    public void setModel(String id, String v) { sp.edit().putString("model_" + id, v).apply(); }

    /** Negative value means "do not send temperature". */
    public float getTemperature() { return sp.getFloat("temperature", 0.7f); }
    public void setTemperature(float t) { sp.edit().putFloat("temperature", t).apply(); }

    public int getMaxTokens() { return sp.getInt("max_tokens", 2048); }
    public void setMaxTokens(int t) { sp.edit().putInt("max_tokens", t).apply(); }

    public String getSystemPrompt() {
        return sp.getString("system_prompt", DEFAULT_SYSTEM_PROMPT);
    }
    public void setSystemPrompt(String s) { sp.edit().putString("system_prompt", s).apply(); }

    public boolean isStreaming() { return sp.getBoolean("streaming", true); }
    public void setStreaming(boolean b) { sp.edit().putBoolean("streaming", b).apply(); }

    public void resetProvider(String id) {
        sp.edit().remove("base_" + id).remove("model_" + id)
                .remove("temperature").remove("max_tokens")
                .remove("system_prompt").remove("streaming").apply();
    }

    /** Builds a config without the API key; the caller adds it from SecureStore. */
    public ProviderConfig buildConfig(String providerId) {
        ProviderConfig c = new ProviderConfig();
        c.providerId = providerId;
        c.baseUrl = getBaseUrl(providerId);
        c.model = getModel(providerId);
        c.temperature = getTemperature();
        c.maxTokens = getMaxTokens();
        c.systemPrompt = getSystemPrompt();
        c.apiKey = "";
        return c;
    }

    public String getModelLabel() {
        String id = getActiveProvider();
        String model = getModel(id);
        return ProviderCatalog.get(id).name + " · " + (model.isEmpty() ? "no model set" : model);
    }
}
