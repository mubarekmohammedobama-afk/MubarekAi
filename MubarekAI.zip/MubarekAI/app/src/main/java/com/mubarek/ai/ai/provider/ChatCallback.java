package com.mubarek.ai.ai.provider;

/** Callbacks arrive on a background thread. */
public interface ChatCallback {
    void onDelta(String delta);
    void onComplete(String fullText);
    void onError(AIException error);
}
