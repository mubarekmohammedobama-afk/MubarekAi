package com.mubarek.ai.ai.anthropic;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.mubarek.ai.ai.provider.AIException;
import com.mubarek.ai.ai.provider.BaseProvider;
import com.mubarek.ai.ai.provider.ChatTurn;
import com.mubarek.ai.ai.provider.ProviderConfig;

import java.util.List;

import okhttp3.Request;

/** Anthropic Messages API: POST {baseUrl}/v1/messages */
public class AnthropicProvider extends BaseProvider {
    private static final String API_VERSION = "2023-06-01";

    @Override
    public String id() { return "anthropic"; }

    @Override
    protected Request buildRequest(List<ChatTurn> turns, ProviderConfig cfg, boolean stream)
            throws AIException {
        requireKeyAndModel(cfg);
        String base = normalizeBase(cfg);

        JsonObject body = new JsonObject();
        body.addProperty("model", cfg.model.trim());
        body.addProperty("max_tokens", cfg.maxTokens > 0 ? cfg.maxTokens : 1024);
        if (cfg.systemPrompt != null && !cfg.systemPrompt.trim().isEmpty()) {
            body.addProperty("system", cfg.systemPrompt);
        }
        JsonArray messages = new JsonArray();
        for (ChatTurn t : turns) {
            JsonObject m = new JsonObject();
            m.addProperty("role", t.role);
            m.addProperty("content", t.content);
            messages.add(m);
        }
        body.add("messages", messages);
        if (cfg.temperature >= 0f) body.addProperty("temperature", Math.min(cfg.temperature, 1f));
        if (stream) body.addProperty("stream", true);

        try {
            return new Request.Builder()
                    .url(base + "/v1/messages")
                    .header("x-api-key", cfg.apiKey.trim())
                    .header("anthropic-version", API_VERSION)
                    .header("Accept", stream ? "text/event-stream" : "application/json")
                    .post(jsonBody(body))
                    .build();
        } catch (IllegalArgumentException e) {
            throw new AIException(AIException.Type.INVALID_ENDPOINT,
                    "The Base URL or API key contains invalid characters.");
        }
    }

    @Override
    protected String parseResponse(String body) throws AIException {
        try {
            JsonObject o = JsonParser.parseString(body).getAsJsonObject();
            JsonArray content = o.getAsJsonArray("content");
            if (content == null) {
                throw new AIException(AIException.Type.MALFORMED, "The provider reply had no content.");
            }
            StringBuilder sb = new StringBuilder();
            for (JsonElement el : content) {
                JsonObject block = el.getAsJsonObject();
                if (block.has("type") && "text".equals(block.get("type").getAsString())
                        && block.has("text")) {
                    sb.append(block.get("text").getAsString());
                }
            }
            return sb.toString();
        } catch (JsonParseException | IllegalStateException | ClassCastException | NullPointerException e) {
            throw new AIException(AIException.Type.MALFORMED, "The provider reply could not be understood.");
        }
    }

    @Override
    protected String parseStreamData(String data) throws AIException {
        try {
            JsonObject o = JsonParser.parseString(data).getAsJsonObject();
            String type = o.has("type") ? o.get("type").getAsString() : "";
            if ("error".equals(type)) {
                throw new AIException(AIException.Type.SERVER, "The provider reported an error while streaming.");
            }
            if ("content_block_delta".equals(type)) {
                JsonObject delta = o.getAsJsonObject("delta");
                if (delta != null && delta.has("text")) return delta.get("text").getAsString();
            }
            return null;
        } catch (JsonParseException | IllegalStateException | ClassCastException | NullPointerException e) {
            return null;
        }
    }
}
