package com.mubarek.ai;

import android.app.Application;

import com.mubarek.ai.data.local.AppPrefs;
import com.mubarek.ai.security.SecureStore;

public class MubarekApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        AppPrefs.applyTheme(new AppPrefs(this).getThemeMode());
        // Warm up encrypted storage off the main thread so first use is fast.
        new Thread(() -> SecureStore.get(MubarekApp.this), "secure-store-warmup").start();
    }
}
