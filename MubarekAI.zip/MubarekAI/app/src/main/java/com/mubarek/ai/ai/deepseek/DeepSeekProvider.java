package com.mubarek.ai.ai.deepseek;

import com.mubarek.ai.ai.compatible.OpenAICompatibleProvider;

public class DeepSeekProvider extends OpenAICompatibleProvider {
    public DeepSeekProvider() {
        super("deepseek");
    }
}
