package com.mubarek.ai.ai.provider;

import com.mubarek.ai.ai.anthropic.AnthropicProvider;
import com.mubarek.ai.ai.compatible.OpenAICompatibleProvider;
import com.mubarek.ai.ai.deepseek.DeepSeekProvider;
import com.mubarek.ai.ai.openai.OpenAIProvider;

public final class ProviderFactory {
    private ProviderFactory() {}

    public static AIProvider create(String providerId) {
        switch (providerId) {
            case "anthropic": return new AnthropicProvider();
            case "openai": return new OpenAIProvider();
            case "deepseek": return new DeepSeekProvider();
            default: return new OpenAICompatibleProvider("compatible");
        }
    }
}
