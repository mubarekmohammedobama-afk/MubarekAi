package com.mubarek.ai.ui.chat;

import android.app.Application;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.MutableLiveData;

import com.mubarek.ai.ai.provider.AIException;
import com.mubarek.ai.ai.provider.AIProvider;
import com.mubarek.ai.ai.provider.Cancellable;
import com.mubarek.ai.ai.provider.ChatCallback;
import com.mubarek.ai.ai.provider.ChatTurn;
import com.mubarek.ai.ai.provider.ProviderCatalog;
import com.mubarek.ai.ai.provider.ProviderConfig;
import com.mubarek.ai.ai.provider.ProviderFactory;
import com.mubarek.ai.data.local.AppPrefs;
import com.mubarek.ai.data.local.MessageEntity;
import com.mubarek.ai.data.repository.ChatRepository;
import com.mubarek.ai.security.SecureStore;
import com.mubarek.ai.utils.Event;
import com.mubarek.ai.utils.NetworkUtils;

import java.util.ArrayList;
import java.util.List;

public class ChatViewModel extends AndroidViewModel {

    public static class UiError {
        public final String message;
        public final boolean needsSettings;

        public UiError(String message, boolean needsSettings) {
            this.message = message;
            this.needsSettings = needsSettings;
        }
    }

    private final ChatRepository repo;
    private final AppPrefs prefs;
    private final Handler main = new Handler(Looper.getMainLooper());

    private final MediatorLiveData<List<MessageEntity>> display = new MediatorLiveData<>();
    private final MutableLiveData<Boolean> generating = new MutableLiveData<>(false);
    private final MutableLiveData<Event<UiError>> errors = new MutableLiveData<>();

    private LiveData<List<MessageEntity>> source;
    private List<MessageEntity> lastDb = new ArrayList<>();
    private String streamingText; // main thread only
    private long convId = -1;     // main thread only
    private volatile Cancellable current;
    private long lastEmit;

    public ChatViewModel(@NonNull Application app) {
        super(app);
        repo = ChatRepository.get(app);
        prefs = new AppPrefs(app);
        display.setValue(new ArrayList<>());
    }

    public LiveData<List<MessageEntity>> getDisplay() { return display; }
    public LiveData<Boolean> getGenerating() { return generating; }
    public LiveData<Event<UiError>> getErrors() { return errors; }

    private boolean isGenerating() { return Boolean.TRUE.equals(generating.getValue()); }

    // ---- conversation selection ----

    public void openConversation(long id) {
        stop();
        openConversationInternal(id);
    }

    public void newChat() {
        stop();
        openConversationInternal(-1);
    }

    private void openConversationInternal(long id) {
        convId = id;
        streamingText = null;
        if (source != null) display.removeSource(source);
        lastDb = new ArrayList<>();
        if (id < 0) {
            source = null;
            refresh();
            return;
        }
        source = repo.observeMessages(id);
        display.addSource(source, list -> {
            lastDb = list == null ? new ArrayList<>() : list;
            refresh();
        });
    }

    private void refresh() {
        List<MessageEntity> out = new ArrayList<>(lastDb);
        if (streamingText != null) {
            MessageEntity m = new MessageEntity();
            m.id = -1;
            m.role = "assistant";
            m.content = streamingText;
            out.add(m);
        }
        display.setValue(out);
    }

    // ---- actions ----

    public void send(String rawText) {
        final String text = rawText == null ? "" : rawText.trim();
        if (text.isEmpty() || isGenerating()) return;
        generating.setValue(true);
        final long cid0 = convId;
        repo.io().execute(() -> {
            long cid = cid0;
            if (cid >= 0 && !repo.conversationExists(cid)) cid = -1;
            if (cid < 0) {
                cid = repo.createConversation(titleFrom(text), prefs.getModelLabel());
                final long created = cid;
                main.post(() -> openConversationInternal(created));
            }
            repo.addMessage(cid, "user", text, null);
            repo.touch(cid);
            runGeneration(cid);
        });
    }

    public void regenerate() {
        if (isGenerating() || convId < 0) return;
        generating.setValue(true);
        final long cid = convId;
        repo.io().execute(() -> {
            List<MessageEntity> msgs = repo.getMessages(cid);
            if (!msgs.isEmpty()) {
                MessageEntity last = msgs.get(msgs.size() - 1);
                if ("assistant".equals(last.role)) repo.deleteMessage(last.id);
            }
            runGeneration(cid);
        });
    }

    public void editMessage(final long messageId, String newText) {
        final String text = newText == null ? "" : newText.trim();
        if (text.isEmpty() || isGenerating() || convId < 0) return;
        generating.setValue(true);
        final long cid = convId;
        repo.io().execute(() -> {
            repo.updateMessage(messageId, text);
            repo.deleteAfter(cid, messageId);
            runGeneration(cid);
        });
    }

    public void stop() {
        Cancellable c = current;
        if (c != null) c.cancel();
    }

    // ---- generation (runs on the repository's io thread) ----

    private void runGeneration(final long cid) {
        final String providerId = prefs.getActiveProvider();
        final ProviderConfig cfg = prefs.buildConfig(providerId);
        cfg.apiKey = SecureStore.get(getApplication()).getApiKey(providerId);

        if (!NetworkUtils.isOnline(getApplication())) {
            fail(new AIException(AIException.Type.OFFLINE,
                    "You're offline. Saved chats are still available, but a reply needs an internet connection."));
            return;
        }
        if (cfg.apiKey.isEmpty()) {
            fail(new AIException(AIException.Type.INVALID_KEY,
                    "No API key is set for " + ProviderCatalog.get(providerId).name + ". Add one in Settings."));
            return;
        }

        List<ChatTurn> turns = new ArrayList<>();
        for (MessageEntity m : repo.getMessages(cid)) {
            if (m.content != null && !m.content.trim().isEmpty()) {
                turns.add(new ChatTurn(m.role, m.content));
            }
        }

        main.post(() -> {
            streamingText = "";
            refresh();
        });

        final AIProvider provider = ProviderFactory.create(providerId);
        final StringBuilder acc = new StringBuilder();
        current = provider.chat(turns, cfg, prefs.isStreaming(), new ChatCallback() {
            @Override
            public void onDelta(String delta) {
                acc.append(delta);
                long now = SystemClock.uptimeMillis();
                if (now - lastEmit >= 60) {
                    lastEmit = now;
                    final String snap = acc.toString();
                    main.post(() -> {
                        if (cid == convId && isGenerating()) {
                            streamingText = snap;
                            refresh();
                        }
                    });
                }
            }

            @Override
            public void onComplete(final String full) {
                repo.io().execute(() -> {
                    repo.addMessage(cid, "assistant", full, cfg.model);
                    repo.touch(cid);
                    main.post(() -> finishGeneration(null));
                });
            }

            @Override
            public void onError(final AIException e) {
                final String partial = acc.toString();
                repo.io().execute(() -> {
                    if (!partial.trim().isEmpty()) {
                        repo.addMessage(cid, "assistant", partial, cfg.model);
                        repo.touch(cid);
                    }
                    final AIException shown = e.getType() == AIException.Type.CANCELLED ? null : e;
                    main.post(() -> finishGeneration(shown));
                });
            }
        });
    }

    private void fail(final AIException e) {
        main.post(() -> finishGeneration(e));
    }

    private void finishGeneration(AIException error) {
        current = null;
        streamingText = null;
        generating.setValue(false);
        refresh();
        if (error != null) {
            errors.setValue(new Event<>(new UiError(error.getUserMessage(), error.needsSettings())));
        }
    }

    private static String titleFrom(String text) {
        String t = text.replace('\n', ' ').trim();
        return t.length() > 40 ? t.substring(0, 40).trim() + "…" : t;
    }

    @Override
    protected void onCleared() {
        stop();
        super.onCleared();
    }
}
