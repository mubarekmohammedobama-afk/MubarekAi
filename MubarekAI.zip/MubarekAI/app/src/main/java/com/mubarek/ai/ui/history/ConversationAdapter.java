package com.mubarek.ai.ui.history;

import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.format.DateUtils;
import android.text.style.BackgroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.mubarek.ai.R;
import com.mubarek.ai.data.local.ConversationEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ConversationAdapter extends RecyclerView.Adapter<ConversationAdapter.VH> {

    public interface Listener {
        void onOpen(ConversationEntity c);
        void onMenu(View anchor, ConversationEntity c);
    }

    private final Listener listener;
    private List<ConversationEntity> items = new ArrayList<>();
    private String query = "";

    public ConversationAdapter(Listener listener) {
        this.listener = listener;
    }

    public void setItems(List<ConversationEntity> list, String query) {
        this.items = list == null ? new ArrayList<>() : list;
        this.query = query == null ? "" : query;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_conversation, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        final ConversationEntity c = items.get(position);
        String title = c.title == null ? "" : c.title;
        h.title.setText(highlight(h.itemView, title));
        String when = DateUtils.getRelativeTimeSpanString(
                c.updatedAt, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString();
        h.meta.setText(c.model == null || c.model.isEmpty() ? when : when + " · " + c.model);
        h.pin.setVisibility(c.pinned ? View.VISIBLE : View.GONE);
        h.itemView.setOnClickListener(v -> listener.onOpen(c));
        h.itemView.setOnLongClickListener(v -> {
            listener.onMenu(v, c);
            return true;
        });
        h.more.setOnClickListener(v -> listener.onMenu(v, c));
    }

    private CharSequence highlight(View view, String title) {
        if (query.isEmpty()) return title;
        SpannableString s = new SpannableString(title);
        String lt = title.toLowerCase(Locale.ROOT);
        String lq = query.toLowerCase(Locale.ROOT);
        int color = ContextCompat.getColor(view.getContext(), R.color.highlight);
        int i = lt.indexOf(lq);
        while (i >= 0 && i + lq.length() <= title.length()) {
            s.setSpan(new BackgroundColorSpan(color), i, i + lq.length(),
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            i = lt.indexOf(lq, i + lq.length());
        }
        return s;
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView title, meta;
        final ImageView pin;
        final ImageButton more;

        VH(View v) {
            super(v);
            title = v.findViewById(R.id.convTitle);
            meta = v.findViewById(R.id.convMeta);
            pin = v.findViewById(R.id.convPin);
            more = v.findViewById(R.id.convMore);
        }
    }
}
