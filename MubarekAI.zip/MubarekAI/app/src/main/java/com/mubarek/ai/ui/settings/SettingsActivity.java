package com.mubarek.ai.ui.settings;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.mubarek.ai.R;
import com.mubarek.ai.ai.provider.AIException;
import com.mubarek.ai.ai.provider.ChatCallback;
import com.mubarek.ai.ai.provider.ChatTurn;
import com.mubarek.ai.ai.provider.Cancellable;
import com.mubarek.ai.ai.provider.ProviderCatalog;
import com.mubarek.ai.ai.provider.ProviderConfig;
import com.mubarek.ai.ai.provider.ProviderFactory;
import com.mubarek.ai.data.local.AppPrefs;
import com.mubarek.ai.security.SecureStore;
import com.mubarek.ai.utils.InsetsUtil;
import com.mubarek.ai.utils.NetworkUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SettingsActivity extends AppCompatActivity {

    private AppPrefs prefs;
    private SecureStore secure;
    private Spinner spProvider;
    private TextInputLayout tilKey;
    private TextInputEditText etKey, etBase, etModel, etTemp, etMaxTokens, etSystem;
    private MaterialSwitch swStream;
    private MaterialButton btnTest;
    private TextView tvStatus;
    private Cancellable testCall;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        EdgeToEdge.enable(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        InsetsUtil.apply(findViewById(R.id.root));

        prefs = new AppPrefs(this);
        secure = SecureStore.get(this);

        ((com.google.android.material.appbar.MaterialToolbar) findViewById(R.id.toolbar))
                .setNavigationOnClickListener(v -> finish());

        spProvider = findViewById(R.id.spProvider);
        tilKey = findViewById(R.id.tilKey);
        etKey = findViewById(R.id.etKey);
        etBase = findViewById(R.id.etBase);
        etModel = findViewById(R.id.etModel);
        etTemp = findViewById(R.id.etTemp);
        etMaxTokens = findViewById(R.id.etMaxTokens);
        etSystem = findViewById(R.id.etSystem);
        swStream = findViewById(R.id.swStream);
        btnTest = findViewById(R.id.btnTest);
        tvStatus = findViewById(R.id.tvStatus);

        setupTheme();
        setupProviderSpinner();
        loadGlobalFields();
        setupAbout();

        findViewById(R.id.btnSave).setOnClickListener(v -> save());
        btnTest.setOnClickListener(v -> testConnection());
        findViewById(R.id.btnDeleteKey).setOnClickListener(v -> confirmDeleteKey());
        findViewById(R.id.btnReset).setOnClickListener(v -> confirmReset());
    }

    private String selectedProviderId() {
        return ProviderCatalog.ALL.get(spProvider.getSelectedItemPosition()).id;
    }

    private void setupTheme() {
        RadioGroup group = findViewById(R.id.themeGroup);
        int mode = prefs.getThemeMode();
        group.check(mode == AppPrefs.THEME_LIGHT ? R.id.rbLight
                : mode == AppPrefs.THEME_DARK ? R.id.rbDark : R.id.rbSystem);
        group.setOnCheckedChangeListener((g, checkedId) -> {
            int m = checkedId == R.id.rbLight ? AppPrefs.THEME_LIGHT
                    : checkedId == R.id.rbDark ? AppPrefs.THEME_DARK : AppPrefs.THEME_SYSTEM;
            if (m != prefs.getThemeMode()) {
                prefs.setThemeMode(m);
                AppPrefs.applyTheme(m);
            }
        });
    }

    private void setupProviderSpinner() {
        List<String> names = new ArrayList<>();
        int activeIndex = 0;
        String active = prefs.getActiveProvider();
        for (int i = 0; i < ProviderCatalog.ALL.size(); i++) {
            names.add(ProviderCatalog.ALL.get(i).name);
            if (ProviderCatalog.ALL.get(i).id.equals(active)) activeIndex = i;
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, names);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spProvider.setAdapter(adapter);
        spProvider.setSelection(activeIndex, false);
        loadProviderFields(ProviderCatalog.ALL.get(activeIndex).id);
        spProvider.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loadProviderFields(ProviderCatalog.ALL.get(position).id);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void loadProviderFields(String providerId) {
        etBase.setText(prefs.getBaseUrl(providerId));
        etModel.setText(prefs.getModel(providerId));
        etKey.setText("");
        tilKey.setHelperText(getString(secure.hasApiKey(providerId)
                ? R.string.key_saved_helper : R.string.key_empty_helper));
        tvStatus.setText("");
    }

    private void loadGlobalFields() {
        float t = prefs.getTemperature();
        etTemp.setText(t < 0 ? "" : String.valueOf(t));
        etMaxTokens.setText(String.valueOf(prefs.getMaxTokens()));
        etSystem.setText(prefs.getSystemPrompt());
        swStream.setChecked(prefs.isStreaming());
    }

    private String text(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString().trim();
    }

    /** Parses the temperature field. Returns null (after showing an error) if invalid. */
    private Float parseTemperature() {
        String s = text(etTemp);
        if (s.isEmpty()) return -1f;
        try {
            float v = Float.parseFloat(s);
            if (v < 0f || v > 2f) throw new NumberFormatException();
            return v;
        } catch (NumberFormatException e) {
            tvStatus.setText("Temperature must be between 0 and 2, or empty.");
            return null;
        }
    }

    private Integer parseMaxTokens() {
        try {
            int v = Integer.parseInt(text(etMaxTokens));
            if (v <= 0) throw new NumberFormatException();
            return v;
        } catch (NumberFormatException e) {
            tvStatus.setText("Max output tokens must be a positive whole number.");
            return null;
        }
    }

    private void save() {
        String id = selectedProviderId();
        String base = text(etBase);
        if (!base.isEmpty() && !base.startsWith("https://")) {
            tvStatus.setText("The Base URL must start with https://");
            return;
        }
        Float temp = parseTemperature();
        Integer tokens = parseMaxTokens();
        if (temp == null || tokens == null) return;

        prefs.setBaseUrl(id, base);
        prefs.setModel(id, text(etModel));
        prefs.setTemperature(temp);
        prefs.setMaxTokens(tokens);
        prefs.setSystemPrompt(text(etSystem));
        prefs.setStreaming(swStream.isChecked());
        String key = text(etKey);
        if (!key.isEmpty()) secure.setApiKey(id, key);
        prefs.setActiveProvider(id);
        loadProviderFields(id);
        tvStatus.setText("Saved. " + ProviderCatalog.get(id).name + " is now your active provider.");
    }

    private void testConnection() {
        final String id = selectedProviderId();
        Float temp = parseTemperature();
        Integer tokens = parseMaxTokens();
        if (temp == null || tokens == null) return;

        ProviderConfig cfg = new ProviderConfig();
        cfg.providerId = id;
        cfg.baseUrl = text(etBase);
        cfg.model = text(etModel);
        String typed = text(etKey);
        cfg.apiKey = typed.isEmpty() ? secure.getApiKey(id) : typed;
        cfg.temperature = -1f; // omit for the test
        cfg.maxTokens = 32;
        cfg.systemPrompt = "";

        if (cfg.apiKey.isEmpty()) {
            tvStatus.setText("Enter an API key first.");
            return;
        }
        if (!NetworkUtils.isOnline(this)) {
            tvStatus.setText("You're offline.");
            return;
        }
        tvStatus.setText("Testing…");
        btnTest.setEnabled(false);
        List<ChatTurn> turns = Collections.singletonList(
                new ChatTurn("user", "Reply with the single word OK."));
        testCall = ProviderFactory.create(id).chat(turns, cfg, false, new ChatCallback() {
            @Override public void onDelta(String delta) {}

            @Override
            public void onComplete(String fullText) {
                runOnUiThread(() -> {
                    if (isFinishing()) return;
                    btnTest.setEnabled(true);
                    tvStatus.setText("Connection works. The model replied.");
                });
            }

            @Override
            public void onError(AIException error) {
                final String msg = error.getUserMessage();
                runOnUiThread(() -> {
                    if (isFinishing()) return;
                    btnTest.setEnabled(true);
                    tvStatus.setText(msg);
                });
            }
        });
    }

    private void confirmDeleteKey() {
        final String id = selectedProviderId();
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.btn_delete_key)
                .setMessage(ProviderCatalog.get(id).name)
                .setPositiveButton(R.string.menu_delete, (d, w) -> {
                    secure.deleteApiKey(id);
                    loadProviderFields(id);
                    tvStatus.setText("API key deleted.");
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void confirmReset() {
        final String id = selectedProviderId();
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.btn_reset)
                .setMessage("Restore default Base URL, model and generation settings? Your API key is kept.")
                .setPositiveButton(R.string.btn_reset, (d, w) -> {
                    prefs.resetProvider(id);
                    loadProviderFields(id);
                    loadGlobalFields();
                    tvStatus.setText("Settings reset.");
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void setupAbout() {
        String version = "1.0.0";
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            if (info.versionName != null) version = info.versionName;
        } catch (PackageManager.NameNotFoundException ignored) {
            // keep default
        }
        ((TextView) findViewById(R.id.tvVersion)).setText(
                getString(R.string.app_name) + " · " + getString(R.string.version_label, version));
        ((TextView) findViewById(R.id.tvDeveloper)).setText(
                getString(R.string.developer_label) + ": " + getString(R.string.developer_name));
        findViewById(R.id.tvEmail).setOnClickListener(v -> startActivity(
                new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + getString(R.string.contact_email)))));
        findViewById(R.id.tvPhone).setOnClickListener(v -> startActivity(
                new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + getString(R.string.contact_phone)))));
    }

    @Override
    protected void onDestroy() {
        if (testCall != null) testCall.cancel();
        super.onDestroy();
    }
}
