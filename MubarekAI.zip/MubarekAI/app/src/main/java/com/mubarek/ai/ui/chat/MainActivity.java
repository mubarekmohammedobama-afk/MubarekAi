package com.mubarek.ai.ui.chat;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;
import com.mubarek.ai.R;
import com.mubarek.ai.data.local.AppPrefs;
import com.mubarek.ai.data.local.MessageEntity;
import com.mubarek.ai.security.SecureStore;
import com.mubarek.ai.ui.history.HistoryActivity;
import com.mubarek.ai.ui.onboarding.OnboardingActivity;
import com.mubarek.ai.ui.settings.SettingsActivity;
import com.mubarek.ai.utils.Event;
import com.mubarek.ai.utils.InsetsUtil;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ChatViewModel vm;
    private AppPrefs prefs;
    private MessageAdapter adapter;
    private RecyclerView list;
    private View emptyState;
    private EditText input;
    private MaterialButton sendButton;
    private TextView generatingLabel;
    private TextView tvModel;
    private MaterialToolbar toolbar;
    private boolean generating;

    private final ActivityResultLauncher<Intent> historyLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    long id = result.getData().getLongExtra(HistoryActivity.EXTRA_CONVERSATION_ID, -1);
                    if (id > 0) vm.openConversation(id);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        EdgeToEdge.enable(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        InsetsUtil.apply(findViewById(R.id.root));

        prefs = new AppPrefs(this);
        vm = new ViewModelProvider(this).get(ChatViewModel.class);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        list = findViewById(R.id.messageList);
        emptyState = findViewById(R.id.emptyState);
        input = findViewById(R.id.inputText);
        sendButton = findViewById(R.id.sendButton);
        generatingLabel = findViewById(R.id.generatingLabel);
        tvModel = findViewById(R.id.tvModel);

        adapter = new MessageAdapter(this, new MessageAdapter.Listener() {
            @Override public void onCopy(String text) { copyToClipboard(text); }
            @Override public void onRegenerate() { vm.regenerate(); }
            @Override public void onEdit(MessageEntity message) { showEditDialog(message); }
            @Override public void onResend() { vm.regenerate(); }
        });
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);

        vm.getDisplay().observe(this, this::render);
        vm.getGenerating().observe(this, g -> {
            generating = Boolean.TRUE.equals(g);
            generatingLabel.setVisibility(generating ? View.VISIBLE : View.GONE);
            sendButton.setIconResource(generating ? R.drawable.ic_stop : R.drawable.ic_send);
            sendButton.setContentDescription(getString(generating ? R.string.cd_stop : R.string.cd_send));
        });
        vm.getErrors().observe(this, this::showError);

        sendButton.setOnClickListener(v -> {
            if (generating) {
                vm.stop();
            } else {
                String text = input.getText().toString();
                if (!text.trim().isEmpty()) {
                    input.setText("");
                    vm.send(text);
                }
            }
        });

        bindChip(R.id.chipWrite, "Help me write ");
        bindChip(R.id.chipCode, "Help me with this code: ");
        bindChip(R.id.chipStudy, "Help me study ");
        bindChip(R.id.chipTranslate, "Translate this to English: ");
        bindChip(R.id.chipAnalyze, "Analyze this: ");
        bindChip(R.id.chipBrainstorm, "Brainstorm ideas for ");

        if (!prefs.isOnboarded()) {
            startActivity(new Intent(this, OnboardingActivity.class));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        String label = prefs.getModelLabel();
        toolbar.setSubtitle(label);
        tvModel.setText(label);
        if (prefs.isOnboarded() && !SecureStore.get(this).hasApiKey(prefs.getActiveProvider())) {
            Snackbar.make(findViewById(R.id.root), R.string.no_key_banner, Snackbar.LENGTH_LONG)
                    .setAnchorView(R.id.inputBar)
                    .setAction(R.string.open_settings,
                            v -> startActivity(new Intent(this, SettingsActivity.class)))
                    .show();
        }
    }

    private void render(List<MessageEntity> msgs) {
        adapter.setItems(msgs);
        emptyState.setVisibility(msgs.isEmpty() ? View.VISIBLE : View.GONE);
        if (!msgs.isEmpty()) list.scrollToPosition(msgs.size() - 1);
    }

    private void bindChip(int id, String prompt) {
        findViewById(id).setOnClickListener(v -> {
            input.setText(prompt);
            input.setSelection(prompt.length());
            input.requestFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
        });
    }

    private void showError(Event<ChatViewModel.UiError> event) {
        if (event == null) return;
        ChatViewModel.UiError err = event.getContentIfNotHandled();
        if (err == null) return;
        Snackbar bar = Snackbar.make(findViewById(R.id.root), err.message, Snackbar.LENGTH_LONG)
                .setAnchorView(R.id.inputBar);
        if (err.needsSettings) {
            bar.setAction(R.string.open_settings,
                    v -> startActivity(new Intent(this, SettingsActivity.class)));
        }
        bar.show();
    }

    private void copyToClipboard(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("Mubarek AI", text));
            Snackbar.make(findViewById(R.id.root), R.string.copied, Snackbar.LENGTH_SHORT)
                    .setAnchorView(R.id.inputBar).show();
        }
    }

    private void showEditDialog(final MessageEntity message) {
        final EditText edit = new EditText(this);
        edit.setText(message.content);
        edit.setSelection(edit.getText().length());
        edit.setMinLines(2);
        edit.setMaxLines(8);
        FrameLayout container = new FrameLayout(this);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        container.setPadding(pad, pad / 2, pad, 0);
        container.addView(edit);
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.edit_title)
                .setView(container)
                .setPositiveButton(R.string.save_regenerate,
                        (d, w) -> vm.editMessage(message.id, edit.getText().toString()))
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_new_chat) {
            vm.newChat();
            return true;
        } else if (id == R.id.action_history) {
            historyLauncher.launch(new Intent(this, HistoryActivity.class));
            return true;
        } else if (id == R.id.action_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
