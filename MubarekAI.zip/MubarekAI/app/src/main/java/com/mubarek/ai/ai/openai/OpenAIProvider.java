package com.mubarek.ai.ai.openai;

import com.mubarek.ai.ai.compatible.OpenAICompatibleProvider;

public class OpenAIProvider extends OpenAICompatibleProvider {
    public OpenAIProvider() {
        super("openai");
    }

    @Override
    protected String maxTokensField() {
        return "max_completion_tokens";
    }
}
