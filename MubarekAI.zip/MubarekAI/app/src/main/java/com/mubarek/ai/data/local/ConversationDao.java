package com.mubarek.ai.data.local;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface ConversationDao {
    @Insert
    long insert(ConversationEntity c);

    @Query("SELECT * FROM conversations WHERE archived = 0 ORDER BY pinned DESC, updatedAt DESC")
    LiveData<List<ConversationEntity>> observeAll();

    @Query("SELECT DISTINCT c.* FROM conversations c "
            + "LEFT JOIN messages m ON m.conversationId = c.id "
            + "WHERE c.archived = 0 AND (c.title LIKE :q OR m.content LIKE :q) "
            + "ORDER BY c.pinned DESC, c.updatedAt DESC")
    LiveData<List<ConversationEntity>> search(String q);

    @Query("SELECT COUNT(*) FROM conversations WHERE id = :id")
    int exists(long id);

    @Query("UPDATE conversations SET updatedAt = :t WHERE id = :id")
    void touch(long id, long t);

    @Query("UPDATE conversations SET title = :title WHERE id = :id")
    void rename(long id, String title);

    @Query("UPDATE conversations SET pinned = :pinned WHERE id = :id")
    void setPinned(long id, boolean pinned);

    @Query("UPDATE conversations SET archived = :archived WHERE id = :id")
    void setArchived(long id, boolean archived);

    @Query("DELETE FROM conversations WHERE id = :id")
    void delete(long id);
}
