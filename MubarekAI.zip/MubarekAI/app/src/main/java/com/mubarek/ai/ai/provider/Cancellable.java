package com.mubarek.ai.ai.provider;

public interface Cancellable {
    void cancel();
}
