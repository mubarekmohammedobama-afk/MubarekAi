package com.mubarek.ai.data.local;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface MessageDao {
    @Insert
    long insert(MessageEntity m);

    @Query("SELECT * FROM messages WHERE conversationId = :cid ORDER BY id ASC")
    LiveData<List<MessageEntity>> observe(long cid);

    @Query("SELECT * FROM messages WHERE conversationId = :cid ORDER BY id ASC")
    List<MessageEntity> getAll(long cid);

    @Query("UPDATE messages SET content = :content WHERE id = :id")
    void updateContent(long id, String content);

    @Query("DELETE FROM messages WHERE id = :id")
    void delete(long id);

    @Query("DELETE FROM messages WHERE conversationId = :cid AND id > :id")
    void deleteAfter(long cid, long id);
}
