package com.mubarek.ai.ai.provider;

public class ChatTurn {
    public final String role; // "user" or "assistant"
    public final String content;

    public ChatTurn(String role, String content) {
        this.role = role;
        this.content = content;
    }
}
