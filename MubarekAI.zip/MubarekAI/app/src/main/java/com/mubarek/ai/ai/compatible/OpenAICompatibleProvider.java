package com.mubarek.ai.ai.compatible;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.mubarek.ai.ai.provider.AIException;
import com.mubarek.ai.ai.provider.BaseProvider;
import com.mubarek.ai.ai.provider.ChatTurn;
import com.mubarek.ai.ai.provider.ProviderConfig;

import java.util.List;

import okhttp3.Request;

/** Works with any server that implements POST {baseUrl}/chat/completions. */
public class OpenAICompatibleProvider extends BaseProvider {
    private final String id;

    public OpenAICompatibleProvider(String id) {
        this.id = id;
    }

    @Override
    public String id() { return id; }

    /** Some providers (newer OpenAI models) use a different field name. */
    protected String maxTokensField() { return "max_tokens"; }

    @Override
    protected Request buildRequest(List<ChatTurn> turns, ProviderConfig cfg, boolean stream)
            throws AIException {
        requireKeyAndModel(cfg);
        String base = normalizeBase(cfg);

        JsonObject body = new JsonObject();
        body.addProperty("model", cfg.model.trim());
        JsonArray messages = new JsonArray();
        if (cfg.systemPrompt != null && !cfg.systemPrompt.trim().isEmpty()) {
            messages.add(message("system", cfg.systemPrompt));
        }
        for (ChatTurn t : turns) messages.add(message(t.role, t.content));
        body.add("messages", messages);
        if (cfg.temperature >= 0f) body.addProperty("temperature", cfg.temperature);
        if (cfg.maxTokens > 0) body.addProperty(maxTokensField(), cfg.maxTokens);
        if (stream) body.addProperty("stream", true);

        try {
            return new Request.Builder()
                    .url(base + "/chat/completions")
                    .header("Authorization", "Bearer " + cfg.apiKey.trim())
                    .header("Accept", stream ? "text/event-stream" : "application/json")
                    .post(jsonBody(body))
                    .build();
        } catch (IllegalArgumentException e) {
            throw new AIException(AIException.Type.INVALID_ENDPOINT,
                    "The Base URL or API key contains invalid characters.");
        }
    }

    private static JsonObject message(String role, String content) {
        JsonObject m = new JsonObject();
        m.addProperty("role", role);
        m.addProperty("content", content);
        return m;
    }

    @Override
    protected String parseResponse(String body) throws AIException {
        try {
            JsonObject o = JsonParser.parseString(body).getAsJsonObject();
            JsonArray choices = o.getAsJsonArray("choices");
            if (choices == null || choices.size() == 0) {
                throw new AIException(AIException.Type.MALFORMED, "The provider reply had no choices.");
            }
            JsonObject msg = choices.get(0).getAsJsonObject().getAsJsonObject("message");
            JsonElement c = msg == null ? null : msg.get("content");
            return (c == null || c.isJsonNull()) ? "" : c.getAsString();
        } catch (JsonParseException | IllegalStateException | ClassCastException | NullPointerException e) {
            throw new AIException(AIException.Type.MALFORMED, "The provider reply could not be understood.");
        }
    }

    @Override
    protected String parseStreamData(String data) {
        try {
            JsonObject o = JsonParser.parseString(data).getAsJsonObject();
            JsonArray choices = o.getAsJsonArray("choices");
            if (choices == null || choices.size() == 0) return null;
            JsonObject delta = choices.get(0).getAsJsonObject().getAsJsonObject("delta");
            if (delta == null) return null;
            JsonElement c = delta.get("content");
            return (c == null || c.isJsonNull()) ? null : c.getAsString();
        } catch (JsonParseException | IllegalStateException | ClassCastException | NullPointerException e) {
            return null; // skip unreadable chunk
        }
    }
}
