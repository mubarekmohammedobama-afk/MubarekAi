package com.mubarek.ai.ai.provider;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;

/** Shared OkHttp client. Deliberately has no logging interceptor so secrets never reach logs. */
public final class NetworkClient {
    private static volatile OkHttpClient client;

    private NetworkClient() {}

    public static OkHttpClient get() {
        if (client == null) {
            synchronized (NetworkClient.class) {
                if (client == null) {
                    client = new OkHttpClient.Builder()
                            .connectTimeout(20, TimeUnit.SECONDS)
                            .readTimeout(90, TimeUnit.SECONDS)
                            .writeTimeout(30, TimeUnit.SECONDS)
                            .retryOnConnectionFailure(true)
                            .build();
                }
            }
        }
        return client;
    }
}
