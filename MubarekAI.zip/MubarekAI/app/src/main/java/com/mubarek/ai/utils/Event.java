package com.mubarek.ai.utils;

/** One-shot LiveData payload (errors, navigation) that must be handled only once. */
public class Event<T> {
    private final T content;
    private boolean handled;

    public Event(T content) {
        this.content = content;
    }

    public T getContentIfNotHandled() {
        if (handled) return null;
        handled = true;
        return content;
    }
}
