package com.mubarek.ai.data.local;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "conversations")
public class ConversationEntity {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public String title;
    public long createdAt;
    public long updatedAt;
    public String model;
    public boolean pinned;
    public boolean archived;
}
