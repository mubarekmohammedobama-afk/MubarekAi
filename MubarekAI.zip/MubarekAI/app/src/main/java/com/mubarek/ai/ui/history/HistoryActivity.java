package com.mubarek.ai.ui.history;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.PopupMenu;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.mubarek.ai.R;
import com.mubarek.ai.data.local.ConversationEntity;
import com.mubarek.ai.data.repository.ChatRepository;
import com.mubarek.ai.utils.InsetsUtil;

import java.util.List;

public class HistoryActivity extends AppCompatActivity {
    public static final String EXTRA_CONVERSATION_ID = "conversation_id";

    private ChatRepository repo;
    private ConversationAdapter adapter;
    private View emptyText;
    private LiveData<List<ConversationEntity>> current;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        EdgeToEdge.enable(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        InsetsUtil.apply(findViewById(R.id.root));

        repo = ChatRepository.get(this);
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
        emptyText = findViewById(R.id.emptyText);

        adapter = new ConversationAdapter(new ConversationAdapter.Listener() {
            @Override
            public void onOpen(ConversationEntity c) {
                Intent result = new Intent().putExtra(EXTRA_CONVERSATION_ID, c.id);
                setResult(RESULT_OK, result);
                finish();
            }

            @Override
            public void onMenu(View anchor, ConversationEntity c) {
                showMenu(anchor, c);
            }
        });
        RecyclerView rv = findViewById(R.id.conversationList);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);

        EditText search = findViewById(R.id.searchInput);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { load(s.toString().trim()); }
        });
        load("");
    }

    private void load(final String query) {
        if (current != null) current.removeObservers(this);
        current = query.isEmpty() ? repo.observeConversations() : repo.search("%" + query + "%");
        current.observe(this, list -> {
            adapter.setItems(list, query);
            emptyText.setVisibility(list == null || list.isEmpty() ? View.VISIBLE : View.GONE);
        });
    }

    private void showMenu(View anchor, final ConversationEntity c) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenuInflater().inflate(R.menu.menu_conversation, pm.getMenu());
        pm.getMenu().findItem(R.id.menu_pin).setTitle(c.pinned ? R.string.menu_unpin : R.string.menu_pin);
        pm.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_rename) {
                showRenameDialog(c);
            } else if (id == R.id.menu_pin) {
                repo.setPinned(c.id, !c.pinned);
            } else if (id == R.id.menu_archive) {
                repo.setArchived(c.id, true);
            } else if (id == R.id.menu_delete) {
                new MaterialAlertDialogBuilder(this)
                        .setTitle(R.string.delete_title)
                        .setMessage(R.string.delete_message)
                        .setPositiveButton(R.string.menu_delete, (d, w) -> repo.deleteConversation(c.id))
                        .setNegativeButton(R.string.cancel, null)
                        .show();
            }
            return true;
        });
        pm.show();
    }

    private void showRenameDialog(final ConversationEntity c) {
        final EditText edit = new EditText(this);
        edit.setText(c.title);
        edit.setSelection(edit.getText().length());
        edit.setSingleLine(true);
        FrameLayout container = new FrameLayout(this);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        container.setPadding(pad, pad / 2, pad, 0);
        container.addView(edit);
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.rename_title)
                .setView(container)
                .setPositiveButton(R.string.save, (d, w) -> {
                    String t = edit.getText().toString().trim();
                    if (!t.isEmpty()) repo.rename(c.id, t);
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
}
