package com.mubarek.ai.data.repository;

import android.content.Context;

import androidx.lifecycle.LiveData;

import com.mubarek.ai.data.local.AppDatabase;
import com.mubarek.ai.data.local.ConversationDao;
import com.mubarek.ai.data.local.ConversationEntity;
import com.mubarek.ai.data.local.MessageDao;
import com.mubarek.ai.data.local.MessageEntity;

import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Single access point for chat data. Methods marked "blocking" must be called
 * from the io() executor, never from the main thread.
 */
public class ChatRepository {
    private static volatile ChatRepository instance;
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();

    private final ConversationDao conversations;
    private final MessageDao messages;

    public static ChatRepository get(Context context) {
        if (instance == null) {
            synchronized (ChatRepository.class) {
                if (instance == null) instance = new ChatRepository(context.getApplicationContext());
            }
        }
        return instance;
    }

    private ChatRepository(Context context) {
        AppDatabase db = AppDatabase.get(context);
        conversations = db.conversationDao();
        messages = db.messageDao();
    }

    public Executor io() { return IO; }

    // ---- Observables (safe on main thread) ----
    public LiveData<List<ConversationEntity>> observeConversations() {
        return conversations.observeAll();
    }

    public LiveData<List<ConversationEntity>> search(String likePattern) {
        return conversations.search(likePattern);
    }

    public LiveData<List<MessageEntity>> observeMessages(long conversationId) {
        return messages.observe(conversationId);
    }

    // ---- Blocking ----
    public long createConversation(String title, String model) {
        ConversationEntity c = new ConversationEntity();
        c.title = title;
        c.model = model;
        c.createdAt = System.currentTimeMillis();
        c.updatedAt = c.createdAt;
        return conversations.insert(c);
    }

    public boolean conversationExists(long id) {
        return conversations.exists(id) > 0;
    }

    public long addMessage(long conversationId, String role, String content, String model) {
        MessageEntity m = new MessageEntity();
        m.conversationId = conversationId;
        m.role = role;
        m.content = content;
        m.model = model;
        m.createdAt = System.currentTimeMillis();
        return messages.insert(m);
    }

    public List<MessageEntity> getMessages(long conversationId) {
        return messages.getAll(conversationId);
    }

    public void updateMessage(long id, String content) { messages.updateContent(id, content); }
    public void deleteMessage(long id) { messages.delete(id); }
    public void deleteAfter(long conversationId, long messageId) {
        messages.deleteAfter(conversationId, messageId);
    }
    public void touch(long conversationId) {
        conversations.touch(conversationId, System.currentTimeMillis());
    }

    // ---- Fire-and-forget conveniences ----
    public void rename(long id, String title) { IO.execute(() -> conversations.rename(id, title)); }
    public void setPinned(long id, boolean pinned) { IO.execute(() -> conversations.setPinned(id, pinned)); }
    public void setArchived(long id, boolean a) { IO.execute(() -> conversations.setArchived(id, a)); }
    public void deleteConversation(long id) { IO.execute(() -> conversations.delete(id)); }
}
