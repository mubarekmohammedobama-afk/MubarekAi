package com.mubarek.ai.data.local;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "messages",
        foreignKeys = @ForeignKey(
                entity = ConversationEntity.class,
                parentColumns = "id",
                childColumns = "conversationId",
                onDelete = ForeignKey.CASCADE),
        indices = {@Index("conversationId")})
public class MessageEntity {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public long conversationId;
    /** "user" or "assistant". */
    public String role;
    public String content;
    public long createdAt;
    public String model;
}
