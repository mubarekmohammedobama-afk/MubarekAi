package com.mubarek.ai.ai.provider;

import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import javax.net.ssl.SSLException;

/** Carries a user-friendly message. Never includes API keys or auth headers. */
public class AIException extends Exception {
    public enum Type {
        OFFLINE, NO_INTERNET, INVALID_KEY, RATE_LIMIT, SERVER, TIMEOUT, BAD_REQUEST,
        INVALID_ENDPOINT, EMPTY_RESPONSE, MALFORMED, NETWORK, CANCELLED, UNKNOWN
    }

    private final Type type;

    public AIException(Type type, String userMessage) {
        super(userMessage);
        this.type = type;
    }

    public Type getType() { return type; }
    public String getUserMessage() { return getMessage(); }

    public boolean needsSettings() {
        return type == Type.INVALID_KEY || type == Type.INVALID_ENDPOINT;
    }

    /** Whether a failed stream may be retried as a normal (non-streaming) request. */
    public boolean isFallbackEligible() {
        return type == Type.MALFORMED || type == Type.EMPTY_RESPONSE
                || type == Type.SERVER || type == Type.UNKNOWN;
    }

    public static AIException fromHttp(int code, String detail) {
        String extra = (detail == null || detail.isEmpty()) ? "" : " " + detail;
        if (code == 401 || code == 403) {
            return new AIException(Type.INVALID_KEY,
                    "The provider rejected your API key (HTTP " + code
                            + "). Check that it is correct, active and not expired.");
        }
        if (code == 404) {
            return new AIException(Type.INVALID_ENDPOINT,
                    "Endpoint or model not found (HTTP 404). Check the Base URL and Model ID." + extra);
        }
        if (code == 408) {
            return new AIException(Type.TIMEOUT, "The request timed out. Please try again.");
        }
        if (code == 429) {
            return new AIException(Type.RATE_LIMIT,
                    "Rate limit or quota reached (HTTP 429). Wait a moment or check your plan.");
        }
        if (code == 400 || code == 422) {
            return new AIException(Type.BAD_REQUEST,
                    "The provider rejected the request (HTTP " + code
                            + "). The model may be unsupported or a setting is invalid." + extra);
        }
        if (code >= 500) {
            return new AIException(Type.SERVER,
                    "The provider had a server error (HTTP " + code + "). Try again shortly.");
        }
        return new AIException(Type.UNKNOWN, "Unexpected response from the provider (HTTP " + code + ").");
    }

    public static AIException fromIo(IOException e) {
        if (e instanceof SocketTimeoutException) {
            return new AIException(Type.TIMEOUT, "The request timed out. Check your connection and try again.");
        }
        if (e instanceof UnknownHostException || e instanceof ConnectException) {
            return new AIException(Type.NO_INTERNET,
                    "Could not reach the provider. Check your internet connection and the Base URL.");
        }
        if (e instanceof SSLException) {
            return new AIException(Type.NETWORK, "A secure (HTTPS) connection could not be established.");
        }
        return new AIException(Type.NETWORK, "A network error occurred. Please try again.");
    }
}
