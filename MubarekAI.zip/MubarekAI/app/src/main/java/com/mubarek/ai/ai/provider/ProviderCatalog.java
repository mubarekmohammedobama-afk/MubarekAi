package com.mubarek.ai.ai.provider;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Built-in provider presets. Base URLs and model IDs are only defaults; users can
 * change both in Settings, so provider changes never require a code change.
 */
public final class ProviderCatalog {
    public static final class Info {
        public final String id;
        public final String name;
        public final String defaultBaseUrl;
        public final String defaultModel;

        Info(String id, String name, String defaultBaseUrl, String defaultModel) {
            this.id = id;
            this.name = name;
            this.defaultBaseUrl = defaultBaseUrl;
            this.defaultModel = defaultModel;
        }
    }

    public static final List<Info> ALL = Collections.unmodifiableList(Arrays.asList(
            new Info("anthropic", "Anthropic (Claude)", "https://api.anthropic.com", "claude-sonnet-5-5"),
            new Info("openai", "OpenAI", "https://api.openai.com/v1", "gpt-4o-mini"),
            new Info("deepseek", "DeepSeek", "https://api.deepseek.com", "deepseek-chat"),
            new Info("compatible", "OpenAI-compatible (custom URL)", "", "")
    ));

    private ProviderCatalog() {}

    public static Info get(String id) {
        for (Info i : ALL) {
            if (i.id.equals(id)) return i;
        }
        return ALL.get(0);
    }
}
