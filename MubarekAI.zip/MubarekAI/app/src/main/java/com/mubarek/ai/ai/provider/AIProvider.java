package com.mubarek.ai.ai.provider;

import java.util.List;

public interface AIProvider {
    String id();

    /**
     * Sends the conversation to the provider. Returns immediately; results are
     * delivered through the callback on a background thread.
     */
    Cancellable chat(List<ChatTurn> turns, ProviderConfig config, boolean stream, ChatCallback callback);
}
