package com.mubarek.ai.ai.provider;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.BufferedSource;

/**
 * Shared HTTP, streaming (SSE), retry and error-mapping logic. Subclasses only
 * describe how to build a request and parse the provider's JSON.
 */
public abstract class BaseProvider implements AIProvider {
    private static final ExecutorService POOL = Executors.newCachedThreadPool();
    protected static final MediaType JSON_TYPE = MediaType.get("application/json; charset=utf-8");

    protected abstract Request buildRequest(List<ChatTurn> turns, ProviderConfig cfg, boolean stream)
            throws AIException;

    protected abstract String parseResponse(String body) throws AIException;

    /** Returns the text delta contained in one SSE "data:" payload, or null. */
    protected abstract String parseStreamData(String data) throws AIException;

    private static final class Handle implements Cancellable {
        volatile boolean cancelled;
        volatile Call call;

        @Override
        public void cancel() {
            cancelled = true;
            Call c = call;
            if (c != null) c.cancel();
        }
    }

    @Override
    public Cancellable chat(final List<ChatTurn> turns, final ProviderConfig cfg,
                            final boolean stream, final ChatCallback cb) {
        final Handle handle = new Handle();
        POOL.execute(() -> run(turns, cfg, stream, cb, handle));
        return handle;
    }

    private void run(List<ChatTurn> turns, ProviderConfig cfg, boolean stream,
                     ChatCallback cb, Handle h) {
        try {
            String result;
            if (stream) {
                StringBuilder acc = new StringBuilder();
                try {
                    streamOnce(turns, cfg, cb, h, acc);
                    result = acc.toString();
                } catch (AIException e) {
                    if (h.cancelled || acc.length() > 0 || !e.isFallbackEligible()) throw e;
                    result = fullOnce(turns, cfg, h); // graceful fallback to a normal request
                    cb.onDelta(result);
                }
            } else {
                result = fullOnce(turns, cfg, h);
                cb.onDelta(result);
            }
            cb.onComplete(result);
        } catch (AIException e) {
            cb.onError(e);
        }
    }

    private void streamOnce(List<ChatTurn> turns, ProviderConfig cfg, ChatCallback cb,
                            Handle h, StringBuilder acc) throws AIException {
        Request req = buildRequest(turns, cfg, true);
        Response resp = send(req, cfg, h);
        try {
            ResponseBody body = resp.body();
            if (body == null) throw new AIException(AIException.Type.MALFORMED, "The provider sent an empty reply.");
            BufferedSource src = body.source();
            String line;
            while (!h.cancelled && (line = src.readUtf8Line()) != null) {
                if (!line.startsWith("data:")) continue;
                String data = line.substring(5).trim();
                if (data.isEmpty()) continue;
                if ("[DONE]".equals(data)) break;
                String delta = parseStreamData(data);
                if (delta != null && !delta.isEmpty()) {
                    acc.append(delta);
                    cb.onDelta(delta);
                }
            }
        } catch (IOException e) {
            if (h.cancelled) throw cancelled();
            throw AIException.fromIo(e);
        } finally {
            resp.close();
        }
        if (h.cancelled) throw cancelled();
        if (acc.length() == 0) {
            throw new AIException(AIException.Type.EMPTY_RESPONSE, "The model returned an empty response.");
        }
    }

    private String fullOnce(List<ChatTurn> turns, ProviderConfig cfg, Handle h) throws AIException {
        Request req = buildRequest(turns, cfg, false);
        Response resp = send(req, cfg, h);
        String text;
        try {
            ResponseBody body = resp.body();
            if (body == null) throw new AIException(AIException.Type.MALFORMED, "The provider sent an empty reply.");
            text = parseResponse(body.string());
        } catch (IOException e) {
            if (h.cancelled) throw cancelled();
            throw AIException.fromIo(e);
        } finally {
            resp.close();
        }
        if (text == null || text.trim().isEmpty()) {
            throw new AIException(AIException.Type.EMPTY_RESPONSE, "The model returned an empty response.");
        }
        return text;
    }

    private Response send(Request req, ProviderConfig cfg, Handle h) throws AIException {
        int attempt = 0;
        while (true) {
            attempt++;
            if (h.cancelled) throw cancelled();
            Call call = NetworkClient.get().newCall(req);
            h.call = call;
            try {
                Response r = call.execute();
                if (r.isSuccessful()) return r;
                int code = r.code();
                String detail = "";
                if (code == 400 || code == 404 || code == 422) {
                    try {
                        detail = extractDetail(r.peekBody(4096).string(), cfg.apiKey);
                    } catch (IOException ignored) {
                        // detail is optional
                    }
                }
                r.close();
                if ((code == 429 || code >= 500) && attempt < 2) {
                    sleep(1000, h);
                    continue;
                }
                throw AIException.fromHttp(code, detail);
            } catch (IOException e) {
                if (h.cancelled || call.isCanceled()) throw cancelled();
                throw AIException.fromIo(e);
            }
        }
    }

    private static void sleep(long ms, Handle h) throws AIException {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw cancelled();
        }
        if (h.cancelled) throw cancelled();
    }

    private static AIException cancelled() {
        return new AIException(AIException.Type.CANCELLED, "Stopped.");
    }

    /** Pulls a short server message out of an error body, redacting the API key if echoed. */
    private static String extractDetail(String body, String apiKey) {
        try {
            JsonObject o = JsonParser.parseString(body).getAsJsonObject();
            String msg = null;
            JsonElement err = o.get("error");
            if (err != null && err.isJsonObject() && err.getAsJsonObject().has("message")) {
                msg = err.getAsJsonObject().get("message").getAsString();
            } else if (o.has("message")) {
                msg = o.get("message").getAsString();
            }
            if (msg == null) return "";
            if (apiKey != null && !apiKey.isEmpty()) msg = msg.replace(apiKey, "[redacted]");
            if (msg.length() > 200) msg = msg.substring(0, 200) + "…";
            return "Details: " + msg;
        } catch (RuntimeException e) {
            return "";
        }
    }

    // ---- helpers for subclasses ----

    protected static String normalizeBase(ProviderConfig cfg) throws AIException {
        String base = cfg.baseUrl == null ? "" : cfg.baseUrl.trim();
        if (base.isEmpty()) {
            throw new AIException(AIException.Type.INVALID_ENDPOINT, "No Base URL is set. Add one in Settings.");
        }
        if (!base.startsWith("https://")) {
            throw new AIException(AIException.Type.INVALID_ENDPOINT,
                    "The Base URL must start with https:// for security.");
        }
        while (base.endsWith("/")) base = base.substring(0, base.length() - 1);
        return base;
    }

    protected static void requireKeyAndModel(ProviderConfig cfg) throws AIException {
        if (cfg.apiKey == null || cfg.apiKey.trim().isEmpty()) {
            throw new AIException(AIException.Type.INVALID_KEY, "No API key is set. Add one in Settings.");
        }
        if (cfg.model == null || cfg.model.trim().isEmpty()) {
            throw new AIException(AIException.Type.BAD_REQUEST, "No Model ID is set. Add one in Settings.");
        }
    }

    protected static RequestBody jsonBody(JsonObject o) {
        return RequestBody.create(o.toString(), JSON_TYPE);
    }
}
